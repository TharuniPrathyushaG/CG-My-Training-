package com.capgemini.ems.dao;

import java.util.List;
import com.capgemini.ems.dto.EmployeeBean;
import com.capgemini.ems.exception.EmsException;

public interface IEmsDao 
{
	public boolean addEmployee(EmployeeBean employee) throws EmsException;
	public boolean updateEmployee(EmployeeBean employee) throws EmsException;
	List<EmployeeBean> getAll() throws EmsException;
	EmployeeBean searchEmployeeByContact(String contact) throws EmsException;
	EmployeeBean searchEmployeeByDept(int deptid) throws EmsException;
	EmployeeBean searchEmployeeByName(String name) throws EmsException;
	EmployeeBean searchEmployeeById(String id) throws EmsException;
	String userType(String userName, String password) throws EmsException;
}
