package com.capgemini.ems.dao;

public interface IQueryMapper {

	
	 String INSERT_EMPLOYEE_DATA="INSERT INTO employee VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)";
	 String INSERT_USER_MASTER_DATA="INSERT INTO User_Master VALUES(?,?,?,?)";
	 
	 String SELECT_USERTYPE_BY_CREDENTIALS="SELECT UserType from User_Master WHERE UserName =? AND UserPassword=? ";
	 String SELECT_EMPLOYEE_BY_ID=" SELECT * FROM employee WHERE Emp_ID=? ";
	 String SELECT_EMPLOYEE_BY_NAME=" SELECT * FROM employee WHERE Emp_FIRST_NAME=? ";
	 String SELECT_EMPLOYEE_BY_DEPT=" SELECT * FROM employee WHERE EMP_DEPT_ID=? ";
	 String SELECT_EMPLOYEE_BY_CONTACT=" SELECT * FROM employee WHERE EMP_CONTACT_NUM=? ";
	 String SELECT_ALL_EMPLOYEES="SELECT * FROM employee";
	 
	 String UPDATE_EMPLOYEE_DATA="UPDATE employee set emp_first_name=?,EMP_LAST_NAME=?,EMP_DATE_OF_BIRTH=?,EMP_DATE_OF_JOINING=?,EMP_DEPT_ID=?,EMP_GRADE=?,EMP_DESIGNATION=?,EMP_BASIC=?,EMP_GENDER=?,EMP_MARITAL_STATUS=?,EMP_HOME_ADDRESS=?,EMP_CONTACT_NUM=? where EMP_ID=? ";
	 
	 
	 
}
