package com.capgemini.ems.dao;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.ems.dto.EmployeeBean;
import com.capgemini.ems.dto.Gender;
import com.capgemini.ems.dto.MartialStatus;
import com.capgemini.ems.exception.EmsException;
import com.capgemini.ems.util.DBConnection;

public class EmsDaoImpl implements IEmsDao {
	Connection con = null;

	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	int queryResult = 0;
	String userType = "";
	
	/***********************************
	 * Method Name   : userType(userName,password)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Returns userType for authentication
	 ***********************************/
	@Override
	public String userType(String userName, String password)
			throws EmsException {
		try {
			con = DBConnection.getConnection();

			preparedStatement = con
					.prepareStatement(IQueryMapper.SELECT_USERTYPE_BY_CREDENTIALS);
			preparedStatement.setString(1, userName);
			preparedStatement.setString(2, password);

			resultSet = preparedStatement.executeQuery();
			if (resultSet.next()) {
				userType = resultSet.getString("UserType");
			} else {
				userType = "invalid";
			}
		} catch (EmsException ee) {
			throw new EmsException(ee.getMessage() + "\n" + ee.getStackTrace());
		} catch (SQLException e) {
			System.out.println(e.getMessage() + "\n" + e.getStackTrace());
		}
		return userType;
	}

	/***********************************
	 * Method Name   : addEmployee(employee)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Adding details of an employee
	 ***********************************/
	@Override
	public boolean addEmployee(EmployeeBean employee) throws EmsException {
		boolean isSuccessful = false;

		try {

			con = DBConnection.getConnection();
			preparedStatement = con
					.prepareStatement(IQueryMapper.INSERT_EMPLOYEE_DATA);

			preparedStatement.setString(1, employee.getEmpId());
			preparedStatement.setString(2, employee.getEmpFirstName());
			preparedStatement.setString(3, employee.getEmpLastName());
			preparedStatement.setDate(4, employee.getEmpDateofBirth());
			preparedStatement.setDate(5, employee.getEmpDateofJoining());
			preparedStatement.setInt(6, employee.getDeptId());
			preparedStatement.setString(7, employee.getGrade());
			preparedStatement.setString(8, employee.getDesignation());
			preparedStatement.setInt(9, employee.getEmpBasic());
			preparedStatement.setString(10, (employee.getGender()).toString());
			preparedStatement.setString(11,
					(employee.getEmpMartialstatus()).toString());
			preparedStatement.setString(12, employee.getEmpHomeAddress());
			preparedStatement.setString(13, employee.getContactNumber());

			int count = preparedStatement.executeUpdate();
			System.out.println("---" + count);
			if (count > 0) {
				isSuccessful = true;
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return isSuccessful;
	}

	/***********************************
	 * Method Name   : updateEmployee(employee)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Updating details of an employee
	 ***********************************/
	@Override
	public boolean updateEmployee(EmployeeBean employee) throws EmsException {
		boolean isSuccessful = false;
		try {

			con = DBConnection.getConnection();
			preparedStatement = con
					.prepareStatement(IQueryMapper.UPDATE_EMPLOYEE_DATA);
			preparedStatement.setString(13, employee.getEmpId());
			preparedStatement.setString(1, employee.getEmpFirstName());
			preparedStatement.setString(2, employee.getEmpLastName());
			preparedStatement.setDate(3, employee.getEmpDateofBirth());
			preparedStatement.setDate(4, employee.getEmpDateofJoining());
			preparedStatement.setInt(5, employee.getDeptId());
			//System.out.println(employee.getGrade());
			preparedStatement.setString(6, employee.getGrade());
			preparedStatement.setString(7, employee.getDesignation());
			preparedStatement.setInt(8, employee.getEmpBasic());
			preparedStatement.setString(9, (employee.getGender()).toString());
			preparedStatement.setString(10,
					(employee.getEmpMartialstatus()).toString());
			preparedStatement.setString(11, employee.getEmpHomeAddress());
			preparedStatement.setString(12, employee.getContactNumber());

			int count = preparedStatement.executeUpdate();
			System.out.println("//////////-----------//////" + count);
			if (count > 0) {
				isSuccessful = true;
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return isSuccessful;
	}

	/***********************************
	 * Method Name   : searchEmployeeById(id)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by Employee ID
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeById(String id) throws EmsException {

		EmployeeBean employeeBean = new EmployeeBean();
		try {

			con = DBConnection.getConnection();
			preparedStatement = con
					.prepareStatement(IQueryMapper.SELECT_EMPLOYEE_BY_ID);

			preparedStatement.setString(1, id);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employeeBean = mapRow(resultSet);
			} 
			else
				employeeBean=null;

		}catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (EmsException ee) {
			throw new EmsException(ee.getMessage() + "\n" + ee.getStackTrace());
		}
		return employeeBean;

	}
	
	/***********************************
	 * Method Name   : searchEmployeeByName(name)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by First Name
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeByName(String name) throws EmsException {

		EmployeeBean employeeBean = new EmployeeBean();
		try {

			con = DBConnection.getConnection();
			preparedStatement = con
					.prepareStatement(IQueryMapper.SELECT_EMPLOYEE_BY_NAME);

			preparedStatement.setString(1, name);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employeeBean = mapRow(resultSet);
			}
			else
				employeeBean=null;


		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (EmsException ee) {
			throw new EmsException(ee.getMessage() + "\n" + ee.getStackTrace());
		}
		return employeeBean;

	}

	/***********************************
	 * Method Name   : searchEmployeeByDept(deptid)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by Department Id
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeByDept(int deptid) throws EmsException {

		EmployeeBean employeeBean = new EmployeeBean();
		try {

			con = DBConnection.getConnection();
			preparedStatement = con
					.prepareStatement(IQueryMapper.SELECT_EMPLOYEE_BY_DEPT);

			preparedStatement.setInt(1, deptid);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employeeBean = mapRow(resultSet);
			} else
				employeeBean=null;
			
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (EmsException ee) {
			throw new EmsException(ee.getMessage() + "\n" + ee.getStackTrace());
		}
		return employeeBean;

	}

	/***********************************
	 * Method Name   : searchEmployeeByContact(contact)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by contact number
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeByContact(String contact) throws EmsException {

		EmployeeBean employeeBean = new EmployeeBean();
		try {

			con = DBConnection.getConnection();
			preparedStatement = con
					.prepareStatement(IQueryMapper.SELECT_EMPLOYEE_BY_CONTACT);

			preparedStatement.setString(1, contact);
			ResultSet resultSet = preparedStatement.executeQuery();

			if (resultSet.next()) {
				employeeBean = mapRow(resultSet);
			}

			else
				employeeBean=null;

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (EmsException ee) {
			throw new EmsException(ee.getMessage() + "\n" + ee.getStackTrace());
		}
		return employeeBean;
	
	}

	/***********************************
	 * Method Name   : getAll()
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 * Description   : Retrieving all employees
	 ***********************************/
	@Override
	public List<EmployeeBean> getAll() throws EmsException {
		List<EmployeeBean> employeeBeanList = new ArrayList<EmployeeBean>();
		EmployeeBean employeeBean = new EmployeeBean();

		try {
			con = DBConnection.getConnection();
			preparedStatement = con
					.prepareStatement(IQueryMapper.SELECT_ALL_EMPLOYEES);

			ResultSet resultSet = preparedStatement.executeQuery();

			while (resultSet.next()) {
				employeeBean = mapRow(resultSet);
				employeeBeanList.add(employeeBean);
			}

		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (EmsException e) {
			throw new EmsException(e.getMessage());
		}
		return employeeBeanList;

	}

	/***********************************
	 * Method Name   : mapRow(resultSet)
	 * Class Name    : EmsDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 07/01/2017
	 ***********************************/
	public EmployeeBean mapRow(ResultSet resultSet) {

		EmployeeBean employeeBean = new EmployeeBean();

		try {

			employeeBean.setEmpId(resultSet.getString("Emp_ID"));
			employeeBean.setEmpFirstName(resultSet.getString("Emp_First_Name"));
			employeeBean.setEmpLastName(resultSet.getString("Emp_Last_Name"));
			employeeBean.setEmpDateofBirth((resultSet
					.getDate("Emp_Date_of_Birth")));
			employeeBean.setEmpDateofJoining((resultSet
					.getDate("Emp_Date_of_Joining")));
			employeeBean.setDeptId(resultSet.getInt("Emp_Dept_ID"));
			employeeBean.setGrade(resultSet.getString("Emp_Grade"));
			employeeBean.setDesignation(resultSet.getString("Emp_Designation"));
			employeeBean.setEmpBasic(resultSet.getInt("Emp_Basic"));
			employeeBean.setGender(Gender.valueOf(resultSet
					.getString("Emp_Gender")));
			employeeBean.setEmpMartialstatus(MartialStatus.valueOf(resultSet
					.getString("Emp_Marital_Status")));
			employeeBean.setEmpHomeAddress(resultSet
					.getString("Emp_Home_Address"));
			employeeBean.setContactNumber(resultSet
					.getString("Emp_Contact_Num"));
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		return employeeBean;

	}

}
