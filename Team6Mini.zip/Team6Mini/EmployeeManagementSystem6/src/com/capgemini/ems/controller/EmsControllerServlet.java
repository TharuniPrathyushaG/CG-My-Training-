package com.capgemini.ems.controller;

import java.io.IOException;
import java.sql.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.ems.dto.EmployeeBean;
import com.capgemini.ems.dto.Gender;
import com.capgemini.ems.dto.MartialStatus;
import com.capgemini.ems.exception.EmsException;
import com.capgemini.ems.service.AdminService;
import com.capgemini.ems.service.AuthenticationService;
import com.capgemini.ems.service.UserService;

@WebServlet("*.obj")
public class EmsControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		String path = request.getServletPath().trim();
		String view = "";
		System.out.println(path + "-----------");
		AuthenticationService authenticationService = null;
		UserService userService = new UserService();
		AdminService adminService = new AdminService();
		EmployeeBean employeeBean = new EmployeeBean();

		switch (path) {

		case "/MainOptionScreen.obj":

			try {
				authenticationService = new AuthenticationService();
				String userType = authenticationService.userType(
						request.getParameter("userName"),
						request.getParameter("password"));
				System.out.println(userType + "==================");
				if (userType.endsWith("admin")) {
					view = "pages/AdminMainOptionScreen.jsp";
				} else if (userType.endsWith("employee")) {
					view = "pages/UserMainOptionScreen.jsp";
				} else {
					System.out
							.println("-----------------invalid user--------------");
					view = "pages/Error.jsp";
				}

			} catch (EmsException exp) {
				System.out.println(exp.getMessage());
			}
			break;

		case "/adminController.obj":

			if (request.getParameter("search") != null) {
				try {

					request.setAttribute("employeeBeanList",
							adminService.getAll());
					view = "pages/DisplayAll.jsp";
				} catch (EmsException exp) {
					System.out.println(exp.getMessage());
				}
			} else if (request.getParameter("add") != null) {
				System.out.println("----------add-----------");
				view = "pages/AddEmployee.jsp";

			} else {
				System.out.println("----------invalid selection-----------");
			}

			break;

		case "/addingToDataBase.obj":

			try {
				employeeBean.setContactNumber(request.getParameter("contact"));
				employeeBean.setDeptId(Integer.parseInt(request
						.getParameter("empDepartment")));
				employeeBean
						.setDesignation(request.getParameter("designation"));
				employeeBean.setEmpBasic(Integer.parseInt(request
						.getParameter("salary")));
				employeeBean.setEmpDateofBirth(Date.valueOf(request
						.getParameter("empDateofBirth")));
				employeeBean.setEmpDateofJoining(Date.valueOf(request
						.getParameter("empDateofJoining")));
				employeeBean.setEmpFirstName(request.getParameter("name"));
				employeeBean.setEmpHomeAddress(request.getParameter("address"));
				employeeBean.setEmpId(request.getParameter("id"));
				employeeBean.setEmpLastName(request.getParameter("lname"));
				employeeBean.setEmpMartialstatus(MartialStatus.valueOf(request
						.getParameter("mstatus")));
				employeeBean.setGender(Gender.valueOf(request
						.getParameter("gender")));
				employeeBean.setGrade(request.getParameter("grades"));
				employeeBean.setEmpDepartment(request
						.getParameter("empDepartment"));

				Boolean isSuccessful = adminService.addEmployee(employeeBean);
				System.out.println(isSuccessful + "------------");
				if (isSuccessful) {
					view = "pages/Success.jsp";
				} else {
					view = "pages/error1.jsp";
				}
			} catch (EmsException e) {
				System.out.println(e.getMessage());
			}
			break;

		case "/ModifyingInDataBase.obj":

			System.out.println("----------"
					+ request.getParameter("employeeId"));
			try {

				employeeBean = adminService.searchEmployeeById(request
						.getParameter("employeeId"));
				request.setAttribute("employeeBean", employeeBean);
				if (employeeBean != null)
					view = "pages/ModifyEmployeeByAdmin.jsp";
				else
					view = "pages/error1.jsp";

			} catch (EmsException e) {
				System.out.println(e.getMessage());
			}
			break;

		case "/updatingDetails.obj":

			try {

				employeeBean.setEmpId(request.getParameter("empId"));
				System.out.println(request.getParameter("empId")
						+ "-*-*-*-*-*-*-*-*-*-*-*-*-*");
				employeeBean.setContactNumber(request
						.getParameter("contactNumber"));
				employeeBean.setDeptId(Integer.parseInt(request
						.getParameter("deptId")));
				employeeBean
						.setDesignation(request.getParameter("designation"));
				employeeBean.setEmpBasic(Integer.parseInt(request
						.getParameter("empBasic")));

				employeeBean.setEmpDateofBirth(Date.valueOf(request
						.getParameter("empDateofBirth")));
				employeeBean.setEmpDateofJoining(Date.valueOf(request
						.getParameter("empDateofJoining")));
				employeeBean.setEmpFirstName(request
						.getParameter("empFirstName"));
				employeeBean.setEmpHomeAddress(request
						.getParameter("empHomeAddress"));

				employeeBean
						.setEmpLastName(request.getParameter("empLastName"));
				employeeBean.setEmpMartialstatus(MartialStatus.valueOf(request
						.getParameter("empMartialstatus")));
				employeeBean.setGender(Gender.valueOf(request
						.getParameter("gender")));
				employeeBean.setGrade(request.getParameter("grade"));

				Boolean isSuccessful = adminService
						.updateEmployee(employeeBean);
				System.out.println(isSuccessful + "------------");
				if (isSuccessful) {
					view = "pages/Success1.jsp";
				} else {
					view = "pages/ErrorInUpdating.jsp";
				}
				// request.setAttribute("employeeBeanList",
				// adminService.getAll());
				// view = "pages/DisplayAll.jsp";
			} catch (EmsException e) {
				System.out.println(e.getMessage());
			}
			break;

		case "/search.obj":
			try {
				employeeBean = userService.searchEmployeeById(request
						.getParameter("search"));
				HttpSession session = request.getSession();
				session.setAttribute("emp", employeeBean);
				if (employeeBean != null) {
					view = "pages/DisplayEmployeeDetails.jsp";
				} else {
					view = "pages/error1.jsp";
				}

			} catch (EmsException exp) {
				System.out.println(exp.getMessage());
			}
			break;

		case "/searchN.obj":
			try {

				employeeBean = userService.searchEmployeeByName(request
						.getParameter("search"));
				HttpSession session = request.getSession();
				session.setAttribute("emp", employeeBean);

				if (employeeBean != null) {
					view = "pages/DisplayEmployeeDetails.jsp";
				} else {
					view = "pages/error1.jsp";
				}
			} catch (EmsException exp) {
				System.out.println(exp.getMessage());
			}
			break;

		case "/searchD.obj":
			try {
				int deptid = Integer.parseInt(request.getParameter("search"));
				employeeBean = userService.searchEmployeeByDept(deptid);
				HttpSession session = request.getSession();
				session.setAttribute("emp", employeeBean);

				if (employeeBean != null) {
					view = "pages/DisplayEmployeeDetails.jsp";
				} else {
					view = "pages/error1.jsp";
				}
			} catch (EmsException exp) {
				System.out.println(exp.getMessage());
			}
			break;

		case "/searchC.obj":
			try {

				employeeBean = userService.searchEmployeeByContact(request
						.getParameter("search"));
				HttpSession session = request.getSession();
				session.setAttribute("emp", employeeBean);

				if (employeeBean != null) {
					view = "pages/DisplayEmployeeDetails.jsp";
				} else {
					view = "pages/error1.jsp";
				}

			} catch (EmsException exp) {
				System.out.println(exp.getMessage());
			}
			break;

		default:
			break;

		}
		request.getRequestDispatcher(view).forward(request, response);

	}

}
