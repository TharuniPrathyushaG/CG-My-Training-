package com.capgemini.ems.dto;

public class GradeMasterBean {
	
	private String gradeCode;
	private String description;
	private int minSalary;
	private int maxSalary;
	
	public GradeMasterBean() {
		super();
	}

	public GradeMasterBean(String gradeCode, String description, int minSalary,
			int maxSalary) {
		super();
		this.gradeCode = gradeCode;
		this.description = description;
		this.minSalary = minSalary;
		this.maxSalary = maxSalary;
	}

	public String getGradeCode() {
		return gradeCode;
	}

	public void setGradeCode(String gradeCode) {
		this.gradeCode = gradeCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getMinSalary() {
		return minSalary;
	}

	public void setMinSalary(int minSalary) {
		this.minSalary = minSalary;
	}

	public int getMaxSalary() {
		return maxSalary;
	}

	public void setMaxSalary(int maxSalary) {
		this.maxSalary = maxSalary;
	}
	
	/*
	 Grade_Code VARCHAR2(9),
Description VARCHAR2(10),
Min_Salary NUMBER(8),
Max_Salary NUMBER(8)
	 */

}
