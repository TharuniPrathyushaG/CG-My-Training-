package com.capgemini.ems.dto;

public class DepartmentBean {
	
	private int deptId;
	private String deptName;
	/*Dept_ID NUMBER(9), 
	Dept_Name VARCHAR2(50) */
	
	public DepartmentBean(int deptId, String deptName) {
		super();
		this.deptId = deptId;
		this.deptName = deptName;
	}
	public DepartmentBean() {
		super();
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
}
