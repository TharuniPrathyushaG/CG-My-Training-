package com.capgemini.ems.dto;

public enum MartialStatus {

		MARRIED,SEPERATED,DIVORCED,WIDOWED,SINGLE,
		married,seperated,divorced,widowed,single;
		
}
