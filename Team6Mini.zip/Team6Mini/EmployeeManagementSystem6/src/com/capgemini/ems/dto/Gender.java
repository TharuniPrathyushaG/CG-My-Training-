package com.capgemini.ems.dto;

public enum Gender {
	male,female,MALE,FEMALE;
}
