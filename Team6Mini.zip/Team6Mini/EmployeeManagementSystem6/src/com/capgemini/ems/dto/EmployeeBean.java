package com.capgemini.ems.dto;

import java.sql.Date;

public class EmployeeBean {

	private String empId;
	private String empFirstName;
	private String empLastName;
	private Date empDateofBirth;
	private Date empDateofJoining;
	private int deptId;
	private String grade;
	private String designation;
	private int empBasic;
	private Gender gender;
	private MartialStatus empMartialstatus;
	private String empHomeAddress;
	private String contactNumber;
	private String empDepartment;
	
	
	/*Emp_ID VARCHAR2(6),
	Emp_First_Name VARCHAR2(25),
	Emp_Last_Name VARCHAR2(25), 
	Emp_Date_of_Birth DATE, 
	Emp_Date_of_Joining DATE,
	Emp_Dept_ID NUMBER(8),
	Emp_Grade VARCHAR2(5),
	Emp_Designation VARCHAR2(50),
	Emp_Basic NUMBER(8), 
	Emp_Gender VARCHAR2(8),
	Emp_Marital_Status VARCHAR2(9), 
	Emp_Home_Address VARCHAR2(100), 
	Emp_Contact_Num VARCHAR2(15)*/
	public EmployeeBean() {
		super();
	}
	public EmployeeBean(String empId, String empFirstName, String empLastName,
			Date empDateofBirth, Date empDateofJoining, int deptId,
			String grade, String designation, int empBasic, Gender gender,
			MartialStatus empMartialstatus, String empHomeAddress,
			String contactNumber) {
		super();
		this.empId = empId;
		this.empFirstName = empFirstName;
		this.empLastName = empLastName;
		this.empDateofBirth = empDateofBirth;
		this.empDateofJoining = empDateofJoining;
		this.deptId = deptId;
		this.grade = grade;
		this.designation = designation;
		this.empBasic = empBasic;
		this.gender = gender;
		this.empMartialstatus = empMartialstatus;
		this.empHomeAddress = empHomeAddress;
		this.contactNumber = contactNumber;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpFirstName() {
		return empFirstName;
	}
	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}
	public String getEmpLastName() {
		return empLastName;
	}
	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}
	public Date getEmpDateofBirth() {
		return empDateofBirth;
	}
	public void setEmpDateofBirth(Date empDateofBirth) {
		this.empDateofBirth = empDateofBirth;
	}
	public Date getEmpDateofJoining() {
		return empDateofJoining;
	}
	public void setEmpDateofJoining(Date empDateofJoining) {
		this.empDateofJoining = empDateofJoining;
	}
	public int getDeptId() {
		return deptId;
	}
	public void setDeptId(int deptId) {
		this.deptId = deptId;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public int getEmpBasic() {
		return empBasic;
	}
	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public MartialStatus getEmpMartialstatus() {
		return empMartialstatus;
	}
	public void setEmpMartialstatus(MartialStatus empMartialstatus) {
		this.empMartialstatus = empMartialstatus;
	}
	public String getEmpHomeAddress() {
		return empHomeAddress;
	}
	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getEmpDepartment() {
		return empDepartment;
	}
	public void setEmpDepartment(String empDepartment) {
		this.empDepartment = empDepartment;
	}
	@Override
	public String toString() {
		return "EmployeeBean [empId=" + empId + ", empFirstName="
				+ empFirstName + ", empLastName=" + empLastName
				+ ", empDateofBirth=" + empDateofBirth + ", empDateofJoining="
				+ empDateofJoining + ", deptId=" + deptId + ", grade=" + grade
				+ ", designation=" + designation + ", empBasic=" + empBasic
				+ ", gender=" + gender + ", empMartialstatus="
				+ empMartialstatus + ", empHomeAddress=" + empHomeAddress
				+ ", contactNumber=" + contactNumber + ", empDepartment="
				+ empDepartment + "]";
	}
	
	
	
	
	
	
	
	
}
