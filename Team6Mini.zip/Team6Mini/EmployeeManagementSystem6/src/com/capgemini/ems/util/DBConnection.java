package com.capgemini.ems.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.ems.exception.EmsException;

public class DBConnection {

	static Connection connection;

	public static Connection getConnection() throws  EmsException  {

		try {
			System.out.println("0 LINE");

			InitialContext ic = new InitialContext();
			System.out.println("1ST LINE");
			DataSource ds = (DataSource)ic.lookup("java:/jdbc/PrathyushaDS");
			System.out.println("2nd LINE");
			connection = ds.getConnection();
		} catch (SQLException e) {
			throw new  EmsException ("SQL Error:" + e.getMessage());

		} catch (NamingException e) {
			throw new  EmsException ("message from DB/NamingExc:"
					+ e.getMessage());

		}
		return connection;
	}
}
