package com.capgemini.ems.exception;

public class EmsException extends Exception {

		public EmsException(String msg)
		{
			super(msg);
		}
}
