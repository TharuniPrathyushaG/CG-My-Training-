package com.capgemini.ems.service;

import java.util.List;

import com.capgemini.ems.dao.EmsDaoImpl;
import com.capgemini.ems.dto.EmployeeBean;
import com.capgemini.ems.exception.EmsException;

public class UserService implements IEmployeeService{

	EmsDaoImpl dao = null;

	public UserService() {
		dao = new EmsDaoImpl();
	}

	/***********************************
	 * Method Name   : searchEmployeeById(id)
	 * Class Name    : UserService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by Employee ID
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeById(String id) throws EmsException {

		return dao.searchEmployeeById(id);
	}

	/***********************************
	 * Method Name   : searchEmployeeByName(name)
	 * Class Name    : UserService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by First Name
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeByName(String name) throws EmsException {

		return dao.searchEmployeeByName(name);
	}

	/***********************************
	 * Method Name   : searchEmployeeByDept(deptid)
	 * Class Name    : UserService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by Department Id
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeByDept(int deptid) throws EmsException {

		return dao.searchEmployeeByDept(deptid);
	}

	/***********************************
	 * Method Name   : searchEmployeeByContact(contact)
	 * Class Name    : UserService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by contact number
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeByContact(String contact) throws EmsException {

		return dao.searchEmployeeByContact(contact);
	}

	
	
	
	@Override
	public boolean addEmployee(EmployeeBean employee) throws EmsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<EmployeeBean> getAll() throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateEmployee(EmployeeBean employee) throws EmsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String userType(String userName, String password)
			throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

}
