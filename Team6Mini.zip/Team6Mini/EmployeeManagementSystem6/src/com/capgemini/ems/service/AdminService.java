package com.capgemini.ems.service;

import java.util.List;

import com.capgemini.ems.dao.EmsDaoImpl;
import com.capgemini.ems.dto.EmployeeBean;
import com.capgemini.ems.exception.EmsException;

public class AdminService implements IEmployeeService{

	EmsDaoImpl dao = null;

	public AdminService() {
		dao = new EmsDaoImpl();
	}
	
	/***********************************
	 * Method Name   : addEmployee(employee)
	 * Class Name    : AdminService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Adding details of an employee
	 ***********************************/
	@Override
	public boolean addEmployee(EmployeeBean employee) throws EmsException {

		return dao.addEmployee(employee);

	}

	/***********************************
	 * Method Name   : getAll()
	 * Class Name    : AdminService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Retrieving all employees
	 ***********************************/
	@Override
	public List<EmployeeBean> getAll() throws EmsException {
		return dao.getAll();
	}

	/***********************************
	 * Method Name   : searchEmployeeById(id)
	 * Class Name    : AdminService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Searching employee details by Employee ID
	 ***********************************/
	@Override
	public EmployeeBean searchEmployeeById(String id) throws EmsException {

		return dao.searchEmployeeById(id);
	}
	
	/***********************************
	 * Method Name   :updateEmployee(employee)
	 * Class Name    : AdminService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Updating details of an employee
	 ***********************************/
	@Override
	public boolean updateEmployee(EmployeeBean employee) throws EmsException{
		return dao.updateEmployee(employee);
	}

	
	
	
	@Override
	public String userType(String userName, String password)
			throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeBean searchEmployeeByName(String name) throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeBean searchEmployeeByDept(int deptid) throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeBean searchEmployeeByContact(String contact)
			throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

}
