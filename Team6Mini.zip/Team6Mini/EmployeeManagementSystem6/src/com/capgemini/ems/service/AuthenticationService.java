package com.capgemini.ems.service;

import java.util.List;
import com.capgemini.ems.dao.EmsDaoImpl;
import com.capgemini.ems.dto.EmployeeBean;
import com.capgemini.ems.dto.UserMasterBean;
import com.capgemini.ems.exception.EmsException;

public class AuthenticationService implements IEmployeeService {
	
	EmsDaoImpl dao=null;
	public AuthenticationService()
	{
		dao=new EmsDaoImpl();
	}
	
	/***********************************
	 * Method Name   : userType(userName,password)
	 * Class Name    : AuthenticationService
	 * Package Name  : com.capgemini.ems.service
	 * Date          : 07/01/2017
	 * Description   : Retrieves userType for authentication
	 ***********************************/
	@Override
	public String  userType(String userName,String password) throws EmsException
	{
		return dao.userType(userName, password);
	}

	
	
	
	
	
	@Override
	public boolean addEmployee(EmployeeBean employee) throws EmsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<EmployeeBean> getAll() throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeBean searchEmployeeById(String id) throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateEmployee(EmployeeBean employee) throws EmsException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public EmployeeBean searchEmployeeByName(String name) throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeBean searchEmployeeByDept(int deptid) throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public EmployeeBean searchEmployeeByContact(String contact)
			throws EmsException {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean addMasterBean(UserMasterBean usermaster) throws EmsException {
		// TODO Auto-generated method stub
		return false;
	}

}
