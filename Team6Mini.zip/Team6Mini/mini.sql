CREATE TABLE EMPLOYEE(
Emp_ID VARCHAR2(6) PRIMARY KEY ,
Emp_First_Name VARCHAR2(25),
Emp_Last_Name VARCHAR2(25), 
Emp_Date_of_Birth DATE, 
Emp_Date_of_Joining DATE,
Emp_Dept_ID NUMBER(8),
Emp_Grade VARCHAR2(5),
Emp_Designation VARCHAR2(50),
Emp_Basic NUMBER(8), 
Emp_Gender VARCHAR2(8),
Emp_Marital_Status VARCHAR2(9), 
Emp_Home_Address VARCHAR2(100), 
Emp_Contact_Num VARCHAR2(15)
);

CREATE TABLE User_Master(
UserId VARCHAR2(6), 
UserName VARCHAR2(15), 
UserPassword VARCHAR2(50), 
UserType VARCHAR2(10)
);

CREATE TABLE Department(
Dept_ID NUMBER(9), 
Dept_Name VARCHAR2(50) 
);



CREATE TABLE UserMasterBean6(
UserId VARCHAR2(6), 
UserName VARCHAR2(15), 
UserPassword VARCHAR2(50), 
UserType VARCHAR2(10)
);

CREATE TABLE Grade_Master(
Grade_Code VARCHAR2(9),
Description VARCHAR2(10),
Min_Salary NUMBER(8),
Max_Salary NUMBER(8)
);

insert into user_master values(100,'admin','password','admin');
insert into user_master values(101,'employee','password','employee');
insert into user_master values(102,'user','userpassword','user');


select * from  usermasterbean06;
commit;

insert into UserMasterBean6 values(100,'admin','password','admin');
insert into  UserMasterBean6 values(101,'employee','password','employee');
insert into  UserMasterBean6 values(102,'user','userpassword','user');

insert into UserMaster06 values(100,'admin','password','admin');


delete UserMasterBean06 where userId=102;

insert into UserMasterBean06 values(100,'admin','password','admin');
insert into  UserMasterBean06 values(101,'employee','password','employee');
insert into  UserMasterBean06 values(102,'user','userpassword','user');

commit;