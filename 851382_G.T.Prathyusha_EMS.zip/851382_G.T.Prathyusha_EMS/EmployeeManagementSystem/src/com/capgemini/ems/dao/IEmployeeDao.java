package com.capgemini.ems.dao;

import java.util.List;
import com.capgemini.ems.dto.Employee;

public interface IEmployeeDao {

	Employee addEmployee(Employee employee);
	
	List<Employee> getAllEmployees();
	
}
