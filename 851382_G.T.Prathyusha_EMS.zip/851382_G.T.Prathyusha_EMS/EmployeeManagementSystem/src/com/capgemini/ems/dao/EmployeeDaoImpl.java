package com.capgemini.ems.dao;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;
import org.springframework.stereotype.Repository;

import com.capgemini.ems.dto.Employee;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {
	
	@PersistenceContext
	private EntityManager entityManager;

	/***********************************
	 * Method Name   : addEmployee() 
	 * Author        : G.T.Prathyusha
	 * Class Name    : EmployeeDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 20/01/2017
	 ***********************************/
	@Override
	public Employee addEmployee(Employee employee) {

		if(employee!=null){
			entityManager.persist(employee);
			entityManager.flush();
		}
		return employee;
	}

	/***********************************
	 * Method Name   :  getAllEmployees() 
	 * Author        : G.T.Prathyusha
	 * Class Name    : EmployeeDaoImpl
	 * Package Name  : com.capgemini.ems.dao
	 * Date          : 20/01/2017
	 ***********************************/
	@Override
	public List<Employee> getAllEmployees() {
		TypedQuery<Employee> query = entityManager.createQuery("SELECT e FROM Employee e", Employee.class);
		return query.getResultList();
	}

}
