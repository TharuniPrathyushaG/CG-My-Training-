package com.capgemini.ems.service;

import java.util.List;

import com.capgemini.ems.dto.Employee;


public interface IEmployeeService {

	Employee addEmployee(Employee employee);
	
	List<Employee> getAllEmployees();
}
