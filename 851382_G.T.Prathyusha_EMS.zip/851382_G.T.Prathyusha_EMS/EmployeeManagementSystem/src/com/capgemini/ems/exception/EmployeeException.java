package com.capgemini.ems.exception;


/***********************************
 * Author        : G.T.Prathyusha
 * Class Name    : EmployeeException
 * Package Name  : com.capgemini.ems.exception
 * Date          : 20/01/2017
 ***********************************/
public class EmployeeException extends Exception {
	
	public EmployeeException(String msg)
	{
		super(msg);
	}
}
