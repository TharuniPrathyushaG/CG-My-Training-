package com.cg.iwmvc.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class InventoryServiceImpl implements IInventoryService {

	@Override
	public List<String> getPossibleCateogories() {
		List<String> categories=new ArrayList<String>();
		categories.add("Fruits");
		categories.add("Vegetables");
		categories.add("Pulses");
		categories.add("Cereals");
		categories.add("Others");
		return categories;
	}

	
}
