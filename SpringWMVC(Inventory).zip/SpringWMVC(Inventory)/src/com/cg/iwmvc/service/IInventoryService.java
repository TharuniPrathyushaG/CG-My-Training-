package com.cg.iwmvc.service;

import java.util.List;

public interface IInventoryService {
	
	List<String> getPossibleCateogories();
	
}
