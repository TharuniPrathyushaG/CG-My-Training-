package com.cg.iwmvc.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cg.iwmvc.dto.Item;
import com.cg.iwmvc.service.IInventoryService;

@Controller
public class InventoryController {
	
	private IInventoryService service;

	public IInventoryService getService() {
		return service;
	}

	@Autowired
	public void setService(IInventoryService service) {
		this.service = service;
	}
	
	@RequestMapping("/itemEntry.obj")
	public ModelAndView itemDetailsEntry() {
		
		Item item=new Item();
		item.setCode((int) Math.random());
	
		ModelAndView mv=new ModelAndView();
		mv.setViewName("itemInput");
		mv.addObject("item",item);
		mv.addObject("categories",service.getPossibleCateogories());
		return mv;
	}
	
	@RequestMapping(value="/itemAccept.obj",method=RequestMethod.POST)
	public ModelAndView acceptItemDetails(
			@ModelAttribute("item") @Valid Item item,
			BindingResult bindingResult) 
	{
		ModelAndView mv=null;
		if(bindingResult.hasErrors())
		{
			mv=new ModelAndView();
			mv.setViewName("itemInput");
			mv.addObject("item",item);
			mv.addObject("categories",service.getPossibleCateogories());
		}
		else 
		{
			mv=new ModelAndView("itemOutput","item",item);
		}
		return mv;
	}
	
}
