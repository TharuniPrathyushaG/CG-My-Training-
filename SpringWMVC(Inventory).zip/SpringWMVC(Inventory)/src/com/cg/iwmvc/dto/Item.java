package com.cg.iwmvc.dto;


import java.time.LocalDate;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.format.annotation.DateTimeFormat;

import com.sun.istack.internal.NotNull;

public class Item {
	
	@Min(value=101,message="cannot be less than 1001")
	private int code;
	
	@NotEmpty
	@Size(max=25,min=4,message="should be of 4 to 25 characters in length")
	private String name;
	
	@NotEmpty
	private double rate;
	
	@NotEmpty
	private String category;
	
	@NotNull
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private LocalDate packageDate;
	
	private boolean isFragile;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public LocalDate getPackageDate() {
		return packageDate;
	}

	public void setPackageDate(LocalDate packageDate) {
		this.packageDate = packageDate;
	}

	public boolean isFragile() {
		return isFragile;
	}

	public void setFragile(boolean isFragile) {
		this.isFragile = isFragile;
	}

}
