package com.capgemini.ems.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.exception.EmployeeException;
import com.capgemini.ems.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	private IEmployeeService employeeService;

	public IEmployeeService getEmployeeService() {
		return employeeService;
	}

	public void setEmployeeService(IEmployeeService employeeService) {
		this.employeeService = employeeService;
	}
	
	/***********************************
	 * Method Name   : goToHome() 
	 * Author        : G.T.Prathyusha
	 * Class Name    : EmployeeController
	 * Package Name  : com.capgemini.ems.controller
	 * Date          : 20/01/2017
	 ***********************************/
	@RequestMapping(value="/index.obj",method=RequestMethod.GET)
	public String goToHome(){
		
		return "pages/home";
		
	}
	
	
	/***********************************
	 * Method Name   : showNewEmployee() 
	 * Author        : G.T.Prathyusha
	 * Class Name    : EmployeeController
	 * Package Name  : com.capgemini.ems.controller
	 * Date          : 20/01/2017
	 ***********************************/
	@RequestMapping(value="/addEmployee",method=RequestMethod.GET)
	public ModelAndView showNewEmployee() throws EmployeeException{
		
		ModelAndView mv = null;
		Employee employee = new Employee();
		mv =  new ModelAndView("pages/newEmployee","employee",employee);
		return mv;
	}

	/***********************************
	 * Method Name   : addSuccess() 
	 * Author        : G.T.Prathyusha
	 * Class Name    : EmployeeController
	 * Package Name  : com.capgemini.ems.controller
	 * Date          : 20/01/2017
	 ***********************************/
	@RequestMapping(value = "/addSuccess", method = RequestMethod.POST)
	public ModelAndView addSuccess(@ModelAttribute @Valid Employee employee,
			BindingResult result) throws EmployeeException {
		ModelAndView mv = null;
		if(!result.hasErrors()) {			
			employeeService.addEmployee(employee);
			mv = new ModelAndView("pages/addSuccess", "employee", employee);
		} else {
			mv = new ModelAndView("pages/newEmployee","employee", employee);
		}
		return mv;
		
	}
	
	/***********************************
	 * Method Name   : displayAll() 
	 * Author        : G.T.Prathyusha
	 * Class Name    : EmployeeController
	 * Package Name  : com.capgemini.ems.controller
	 * Date          : 20/01/2017
	 ***********************************/
	@RequestMapping("/getAllEmployees")
	public ModelAndView displayAll() throws EmployeeException {

		ModelAndView mv = new ModelAndView();
		mv.addObject("employees", employeeService.getAllEmployees());
		mv.setViewName("pages/displayAllEmployees");
		return mv;
	}
	
}
