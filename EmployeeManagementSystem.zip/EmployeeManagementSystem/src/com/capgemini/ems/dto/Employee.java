package com.capgemini.ems.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;
import org.hibernate.validator.constraints.NotEmpty;

/*
CREATE TABLE employee(
	employee_code NUMBER PRIMARY KEY, 
	employee_name VARCHAR2(20), 
	employee_gender VARCHAR(10), 
	designation_name VARCHAR2(30), 
	employee_email VARCHAR2(30), 
	employee_phone NUMBER(10));
*/

@Entity
@Table(name="employee")
public class Employee{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int employeeCode;
	
	@NotEmpty
	@Size(min=4,max=40,message="Name should be of 4 to 40 characters in length")
	private String employeeName;
	
	@NotEmpty
	private String employeeGender;
	
	@NotEmpty
	private String designationName;
	
	@NotEmpty
	@Pattern(regexp="[a-z][a-z0-9\\.]*@[a-z][a-z0-9]*\\.[a-z]{3,4}",message="Invalid email.")
	private String employeeEmail;
	
	@NotEmpty
	@Pattern(regexp="[1-9][0-9]{9}",message="10 digit mobile number expected")
	private String employeePhone;
	
	public Employee() {}


	public int getEmployeeCode() {
		return employeeCode;
	}


	public void setEmployeeCode(int employeeCode) {
		this.employeeCode = employeeCode;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getEmployeeGender() {
		return employeeGender;
	}


	public void setEmployeeGender(String employeeGender) {
		this.employeeGender = employeeGender;
	}


	public String getDesignationName() {
		return designationName;
	}


	public void setDesignationName(String designationName) {
		this.designationName = designationName;
	}


	public String getEmployeeEmail() {
		return employeeEmail;
	}


	public void setEmployeeEmail(String employeeEmail) {
		this.employeeEmail = employeeEmail;
	}


	public String getEmployeePhone() {
		return employeePhone;
	}


	public void setEmployeePhone(String employeePhone) {
		this.employeePhone = employeePhone;
	}

	
}
