package com.capgemini.ems.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.capgemini.ems.dao.IEmployeeDao;
import com.capgemini.ems.dto.Employee;


/***********************************
 * Class Name    : EmployeeServiceImpl
 * Package Name  : com.capgemini.ems.service
 * Author        : G.T.Prathyusha
 * Date          : 20/01/2017
 ***********************************/
@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	public IEmployeeDao trDao;
	
	public IEmployeeDao getTrDao() {
		return trDao;
	}

	public void setTrDao(IEmployeeDao trDao) {
		this.trDao = trDao;
	}
	
	/***********************************
	 * Method Name   : addEmplyee()
	 * Class Name    : EmployeeServiceImpl
	 * Package Name  : com.capgemini.ems.service
	 * Author        : G.T.Prathyusha
	 * Date          : 20/01/2017
	 ***********************************/
	@Override
	public Employee addEmployee(Employee employee) {
		return trDao.addEmployee(employee);
	}

	/***********************************
	 * Method Name   : getAllEmployees()
	 * Class Name    : EmployeeServiceImpl
	 * Package Name  : com.capgemini.ems.service
	 * Author        : G.T.Prathyusha
	 * Date          : 20/01/2017
	 ***********************************/
	@Override
	public List<Employee> getAllEmployees() {
		return trDao.getAllEmployees();
	}

}
