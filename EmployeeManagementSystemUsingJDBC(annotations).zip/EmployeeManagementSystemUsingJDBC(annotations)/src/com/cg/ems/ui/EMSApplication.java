package com.cg.ems.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.ems.dtos.EmpGender;
import com.cg.ems.dtos.Employee;
import com.cg.ems.exceptions.EMSException;
import com.cg.ems.services.EmpService;
import com.cg.ems.services.EmpServiceImpl;
import com.cg.ems.util.AppProperties;

@Component("appObj")
public class EMSApplication {

	public Scanner kbin;
	@Autowired
	public EmpService service;
	public DateTimeFormatter dtformatter;
	public Logger rootLog;

	public static void main(String[] args) {
		
		ApplicationContext context= 
				new ClassPathXmlApplicationContext("anno.xml");
		
		EMSApplication appObj= (EMSApplication) context.getBean("appObj");
		
		PropertyConfigurator.configure(AppProperties.LOG_PROPS);
		appObj.rootLog=Logger.getRootLogger();

		appObj.kbin = new Scanner(System.in);
		appObj.dtformatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		int menu = 0;

		while (menu != 6) {
			try {
				System.out.println("\tMenu\tMenu Option");
				System.out.println("--------------------------------");
				System.out.println("\t1\tDisplay All Employees");
				System.out.println("\t2\tAdd Employee");
				System.out.println("\t3\tSearch for Employee");
				System.out.println("\t4\tDelete Employee");
				System.out.println("\t5\tEdit employee");
				System.out.println("\t6\tQuit");

				System.out.print("\n\tmenu? ");
				menu = appObj.kbin.nextInt();

				switch (menu) {
				case 1:
					appObj.doDisplayAll();
					break;
				case 2:
					appObj.doAddEmployee();
					break;
				case 3:
					appObj.doSearchEmployee();
					break;
				case 4:
					appObj.doDeleteEmployee();
					break;
				case 5:
					appObj.doEditEmployee();
					break;
				case 6:
					System.out.println("Application Logged Out");
					break;
				default:
					System.out.println("Invalid Menu!");
				}

			} catch (EMSException e) {
				System.out.println("Operation Failed!");
				System.out.println("Caused By: " + e.getMessage());
			} catch (Exception e) {
				System.out.println("Err: " + e);
				appObj.rootLog.error(e);
				appObj.rootLog.error(Arrays.toString(e.getStackTrace()));
				appObj.kbin.nextLine();
			}
		}

	}

	public void doDisplayAll() throws EMSException {
		List<Employee> emps = service.getAllEmployees();
		if (emps.size() == 0) {
			System.out.println("No Records To Display!");
		} else {
			StringBuffer sb = new StringBuffer(
					"\n\tEmpID#\tName\tBasic\tGender\tDOJ");
			sb.append("\n===============================================================");
			for (Employee emp : emps) {
				sb.append("\n\t").append(emp.getEmpId());
				sb.append("\t").append(emp.getName());
				sb.append("\t").append(emp.getBasic());
				sb.append("\t").append(emp.getGender());
				sb.append("\t").append(
						emp.getDoj().format(dtformatter));
			}
			System.out.println(sb.toString());
		}
	}

	public void doAddEmployee() throws EMSException {
		Employee emp = new Employee();
		System.out.print("Employee Name: ");
		emp.setName(kbin.next());
		System.out.println("Employee Basic: ");
		emp.setBasic(kbin.nextDouble());
		System.out.println("Employee Gender("
				+ Arrays.toString(EmpGender.values()) + "): ");
		emp.setGender(EmpGender.valueOf(kbin.next().trim().toUpperCase()));
		System.out.println("Date of Joining(dd-MM-yyyy): ");
		emp.setDoj(LocalDate.parse(kbin.next(), dtformatter));
		emp = service.addEmployee(emp);
		if (emp != null) {
			System.out.println("Employee Saved Successfully!");
		}
	}

	public void doSearchEmployee() throws EMSException {
		System.out.print("Employee ID: ");
		int empId = kbin.nextInt();
		Employee emp = service.getEmployeeById(empId);
		if (emp == null) {
			System.out.println("Employee not found!");
		} else {
			StringBuffer sb = new StringBuffer();
			sb.append("\n\tEmployee Code: ").append(emp.getEmpId());
			sb.append("\n\tEmployee Name: ").append(emp.getName());
			sb.append("\n\tEmployee Basic: ").append(emp.getBasic());
			sb.append("\n\tGender: ").append(emp.getGender());
			sb.append("\n\tDate of Joining: ").append(emp.getDoj().format(dtformatter));
			System.out.println(sb.toString());
		}
	}

	public void doDeleteEmployee() throws EMSException {
		System.out.print("Employee ID: ");
		int empId = kbin.nextInt();
		boolean isDone = service.removeEmployee(empId);
		if(isDone){
			System.out.println("Employee removed successfully!");
		}else{
			System.out.println("Employee not found!");
		}
	}

	public void doEditEmployee() throws EMSException {
		Employee emp = new Employee();
		System.out.print("Employee ID: ");
		emp.setEmpId(kbin.nextInt());
		System.out.print("Employee Name: ");
		emp.setName(kbin.next());
		System.out.println("Employee Basic: ");
		emp.setBasic(kbin.nextDouble());
		System.out.println("Employee Gender("
				+ Arrays.toString(EmpGender.values()) + "): ");
		emp.setGender(EmpGender.valueOf(kbin.next().trim().toUpperCase()));
		System.out.println("Date of joining (dd-MM-yyyy): ");
		emp.setDoj(LocalDate.parse(kbin.next(), dtformatter));
		emp = service.updateEmployee(emp);
		if (emp != null) {
			System.out.println("Employee Saved Successfully!");
		}
	}

	}


