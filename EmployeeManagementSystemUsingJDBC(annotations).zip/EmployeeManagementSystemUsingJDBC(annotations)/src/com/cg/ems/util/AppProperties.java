package com.cg.ems.util;

public interface AppProperties {
	
	public static String LOG_PROPS="resources/log4j.properties";
	public static String DB_PROPS="resources/dbconfig.properties";

}
