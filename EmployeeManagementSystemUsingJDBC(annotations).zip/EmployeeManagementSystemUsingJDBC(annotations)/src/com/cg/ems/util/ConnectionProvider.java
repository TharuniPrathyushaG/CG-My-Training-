package com.cg.ems.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

import com.cg.ems.exceptions.EMSException;
import com.cg.ems.util.AppProperties;
import com.cg.ems.util.ConnectionProvider;

@Repository
public class ConnectionProvider {

	private Connection connection;
	
	@Value("#{props['db.url']}")
	private String dbUrl;
	
	@Value("#{props['db.uid']}")
	private String dbUid;
	
	@Value("#{props['db.pwd']}")
	private String dbPwd;
	
	@Value("#{props['driver.name']}")
	private String driverName;
	
	private Logger connLog;
	
	private ConnectionProvider() throws EMSException {
		
		PropertyConfigurator.configure(AppProperties.LOG_PROPS);
		connLog=Logger.getLogger(ConnectionProvider.class);
		
		Properties props=new Properties();
		
	}
	
	@PostConstruct
	public void startUp() throws EMSException {
		try {
			//load the DB driver
			Class.forName(driverName);
			
		}  catch (ClassNotFoundException e) {
			connLog.fatal(e);
			connLog.fatal(Arrays.toString(e.getStackTrace()));
			throw new EMSException("Database driver not found");
		}
	}
	
	public Connection getConnection() throws EMSException
	{
		try {
			if(connection==null || connection.isClosed())
			{
				connection=DriverManager.getConnection(dbUrl,dbUid,dbPwd);
			}
		} catch (SQLException e) {
			
			connLog.fatal(e);
			connLog.fatal(Arrays.toString(e.getStackTrace()));
			throw new EMSException("Something went wrong with connection! "+e.getMessage());
		}
		return connection;
	}

	public String getDbUrl() {
		return dbUrl;
	}

	public void setDbUrl(String dbUrl) {
		this.dbUrl = dbUrl;
	}

	public String getDbUid() {
		return dbUid;
	}

	public void setDbUid(String dbUid) {
		this.dbUid = dbUid;
	}

	public String getDbPwd() {
		return dbPwd;
	}

	public void setDbPwd(String dbPwd) {
		this.dbPwd = dbPwd;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}
	
}

