package com.cg.ems.daos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.ems.dtos.EmpGender;
import com.cg.ems.dtos.Employee;
import com.cg.ems.exceptions.EMSException;
import com.cg.ems.daos.QueryMapper;
import com.cg.ems.util.ConnectionProvider;
import com.cg.ems.util.AppProperties;

@Repository
public class EmpDaoImpl implements EmpDao {
	
	@Autowired
	private ConnectionProvider connectionProvider;
	
	private Logger daoLog;
	
	
	public EmpDaoImpl() throws EMSException {
		
		PropertyConfigurator.configure(AppProperties.LOG_PROPS);
		daoLog = Logger.getLogger(EmpDaoImpl.class);
	}
	
	private Employee mapRow(ResultSet result) throws SQLException {
			Employee emp= new Employee();
			emp.setEmpId(result.getInt(1));
			emp.setName(result.getString(2));
			emp.setBasic(result.getDouble(3));
			emp.setGender(EmpGender.valueOf(result.getString(4)));
			emp.setDoj(result.getDate(5).toLocalDate());	
			daoLog.debug("MapRow generated "+emp);
			
			return emp;
	}
				
	@Override
	public Employee addEmployee(Employee emp) throws EMSException {
		if(emp!=null) {
			try(Connection con=connectionProvider.getConnection();
					PreparedStatement pInsert=con.prepareStatement(QueryMapper.INSERT_QRY);
					PreparedStatement pMaxCode=con.prepareStatement(QueryMapper.SELECT_MAX_CODE_QRY);
					){
				pInsert.setString(1,emp.getName());
				pInsert.setDouble(2,emp.getBasic());
				pInsert.setString(3,emp.getGender().toString());
				pInsert.setDate(4,Date.valueOf(emp.getDoj()));
				
				int count=pInsert.executeUpdate();
				
				if(count<=0)
				{
					daoLog.error("Insertion did not happen");
					throw new EMSException("No insertion done");
				}
				else
				{
					ResultSet result=pMaxCode.executeQuery();
					if(result.next()) {
						emp.setEmpId(result.getInt(1));
					}
					else
					{
						throw new EMSException("Could not retrieve Employee ID!");
					}
				}
			}
			catch(SQLException e)
			{
				daoLog.error(e);
				daoLog.error(Arrays.toString(e.getStackTrace()));
				throw new EMSException(e.getMessage());
			}
			catch(RuntimeException e)
			{
				daoLog.error(e);
				daoLog.error(Arrays.toString(e.getStackTrace()));
				throw new EMSException("Something wrong with the details provided");
			}
		}
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EMSException {
		if(emp!=null) {
			try(Connection con=connectionProvider.getConnection();
					PreparedStatement pUpdate=con.prepareStatement(QueryMapper.UPDATE_QRY);
					
					){
				pUpdate.setString(1,emp.getName());
				pUpdate.setDouble(2,emp.getBasic());
				pUpdate.setString(3,emp.getGender().toString());
				pUpdate.setDate(4,Date.valueOf(emp.getDoj()));
				pUpdate.setInt(5,emp.getEmpId());
				
				int count=pUpdate.executeUpdate();
				
				if(count<=0)
				{
					throw new EMSException("No updation done");
				}
			}
			catch(SQLException e)
			{
				daoLog.error(e);
				daoLog.error(Arrays.toString(e.getStackTrace()));
				throw new EMSException(e.getMessage());
			}
		}
		
		return emp;
	}

	@Override
	public boolean removeEmployee(int empId) throws EMSException {
		boolean isDeleted=false;
		try(Connection con=connectionProvider.getConnection();
				PreparedStatement pDelete=con.prepareStatement(QueryMapper.DELETE_QRY);
				
				){
			pDelete.setInt(1,empId);
			
			
			int count=pDelete.executeUpdate();
			
			if(count<=0)
			{
				throw new EMSException("No deletion done");
			}
			else
			{
				isDeleted=true;
			}
		}
		catch(SQLException e)
		{
			daoLog.error(e);
			daoLog.error(Arrays.toString(e.getStackTrace()));
			throw new EMSException(e.getMessage());
		}
		return isDeleted;
	}

	@Override
	public Employee getEmployeeById(int empId) throws EMSException {
		Employee emp=null;
		try(Connection con=connectionProvider.getConnection();
				PreparedStatement pSelect=con.prepareStatement(QueryMapper.SELECT_BY_CODE_QRY);
				){
			
			pSelect.setInt(1,empId);
			ResultSet result=pSelect.executeQuery();
			if(result.next()) {
				emp=mapRow(result);
			}
		}
		catch(SQLException e)
		{
			daoLog.error(e);
			daoLog.error(Arrays.toString(e.getStackTrace()));
			throw new EMSException(e.getMessage());
		}
		
			return emp;
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		List<Employee> empList=null;
		try(Connection con=connectionProvider.getConnection();
				PreparedStatement pSelect=con.prepareStatement(QueryMapper.SELECT_ALL_QRY);
				){
			
			ResultSet result=pSelect.executeQuery();
			empList=new ArrayList<>();
			while(result.next())
				empList.add(mapRow(result));
		}
		catch(SQLException e)
		{
			daoLog.error(e);
			daoLog.error(Arrays.toString(e.getStackTrace()));
			throw new EMSException(e.getMessage());
		}
		
		return empList;
	}

}
