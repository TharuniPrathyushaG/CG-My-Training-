package com.cg.ems.daos;

public interface QueryMapper {
	
	public static String SELECT_ALL_QRY=
			"SELECT * from emp810";
	
	public static String SELECT_BY_CODE_QRY=
			"SELECT * from emp810 where empId=?";
	
	public static String SELECT_MAX_CODE_QRY=
			"SELECT max(empId) from emp810";
	
	public static String INSERT_QRY=
			"INSERT into emp810 values(emp_code_seq.nextval,?,?,?,?)";
	
	public static String UPDATE_QRY=
			"UPDATE emp810 SET name=?,basic=?,gender=?,doj=? where empId=? ";
	
	public static String DELETE_QRY=
			"DELETE from emp810 where empId=?";
	
}
