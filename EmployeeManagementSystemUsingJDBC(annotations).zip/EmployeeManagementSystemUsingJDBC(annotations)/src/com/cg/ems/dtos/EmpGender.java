package com.cg.ems.dtos;

public enum EmpGender {
	MASCULINE,FEMININE;
}
