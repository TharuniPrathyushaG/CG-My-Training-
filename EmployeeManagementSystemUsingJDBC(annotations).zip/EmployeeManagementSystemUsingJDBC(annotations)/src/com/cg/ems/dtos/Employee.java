package com.cg.ems.dtos;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Employee implements Comparable<Employee>,Serializable{
	private int empId;
	private String name;
	private double basic;
	private LocalDate doj;
	private boolean isMarried;
	private EmpGender gender;
	
	public Employee() {}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getBasic() {
		return basic;
	}

	public void setBasic(double basic) {
		this.basic = basic;
	}

	public boolean isMarried() {
		return isMarried;
	}

	public void setMarried(boolean isMarried) {
		this.isMarried = isMarried;
	}

	public EmpGender getGender() {
		return gender;
	}

	public void setGender(EmpGender gender) {
		this.gender = gender;
	}

	public LocalDate getDoj() {
		return doj;
	}

	public void setDoj(LocalDate doj) {
		this.doj = doj;
	}

	public Employee(int empId, String name, double basic, boolean isMarried,
			EmpGender gender, LocalDate doj) {
		super();
		this.empId = empId;
		this.name = name;
		this.basic = basic;
		this.isMarried = isMarried;
		this.gender = gender;
		this.doj = doj;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", basic="
				+ basic + ", isMarried=" + isMarried + ", gender=" + gender
				+ ", doj=" + doj + "]";
	}

	@Override
	public int compareTo(Employee emp) {
		
		return this.empId-emp.empId;
	}
	
}
