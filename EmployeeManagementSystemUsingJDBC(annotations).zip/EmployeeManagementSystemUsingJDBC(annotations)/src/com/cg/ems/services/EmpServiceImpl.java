package com.cg.ems.services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ems.daos.EmpDao;
import com.cg.ems.daos.EmpDaoImpl;
import com.cg.ems.dtos.Employee;
import com.cg.ems.exceptions.EMSException;
import com.cg.ems.util.AppProperties;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired
	private EmpDao empDao;
	private Logger serviceLog;
	
	
	public EmpServiceImpl() throws EMSException
	{
		PropertyConfigurator.configure(AppProperties.LOG_PROPS);
		 serviceLog=Logger.getLogger(EmpServiceImpl.class);
	}
	
	public boolean isValidEmpName(String name)
	{
		Pattern namePattern=Pattern.compile("[A-Z][0-9A_Za-z\\s]{4,24}");
		Matcher nameMatcher=namePattern.matcher(name);
		return nameMatcher.matches();
		//return name!=null && name.length()>3? true : false;
	}
	
	public boolean isValidBasic(double basic)
	{
		return basic>1000 && basic<=100000? true : false;
	}
	
	public boolean isValidDoj(LocalDate doj)
	{
		LocalDate today=LocalDate.now();
		return doj!=null && doj.isBefore(today)? true : false;
	}
	
	public boolean isValidEmployee(Employee emp) throws EMSException
	{
		List<String> errors=new ArrayList<>();
		
		if(!isValidEmpName(emp.getName()))
		{
			errors.add("Employee name must start with capital letter and length should be minimum of 4 characters and maximum of 25 characters");
		}
		if(!isValidBasic(emp.getBasic()))
		{
			errors.add("Basic should be between 1000 and 100000");
		}
		if(!isValidDoj(emp.getDoj()))
		{
			errors.add("Invalid Date of joining");
		}
			
		boolean isValid=errors.size()==0? true : false;
		if(!isValid)
			throw new EMSException("Validation errors:\n"+errors);
		return isValid;
	}
		
	
	@Override
	public Employee addEmployee(Employee emp) throws EMSException {
		if(emp!=null && isValidEmployee(emp)) {
			serviceLog.info("Employee being passed to dao for insertion");
			empDao.addEmployee(emp);
			serviceLog.info("Employee inserted");
		}
		return emp;
	}

	@Override
	public Employee updateEmployee(Employee emp) throws EMSException {
		if(emp!=null && isValidEmployee(emp)) {
			serviceLog.info("employee being passed to dao for updation");
			empDao.updateEmployee(emp);
			serviceLog.info("Employee updated");
		}
		return emp;
	}

	@Override
	public boolean removeEmployee(int empId)throws EMSException {
		
		serviceLog.info(empId+ " being passed to dao for deletion");
		return empDao.removeEmployee(empId);
	}

	@Override
	public Employee getEmployeeById(int empId) throws EMSException {
		
		serviceLog.info(empId+ " being passed to dao for retrieval");
		return empDao.getEmployeeById(empId);
	}

	@Override
	public List<Employee> getAllEmployees() throws EMSException {
		return empDao.getAllEmployees();
	}


}
