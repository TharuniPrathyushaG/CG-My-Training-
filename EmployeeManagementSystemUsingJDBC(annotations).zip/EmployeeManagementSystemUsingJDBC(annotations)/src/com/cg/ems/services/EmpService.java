package com.cg.ems.services;

import java.util.List;


import com.cg.ems.dtos.Employee;
import com.cg.ems.exceptions.EMSException;

public interface EmpService {
	Employee addEmployee(Employee emp) throws EMSException;
	Employee updateEmployee(Employee emp) throws EMSException;
	boolean removeEmployee(int empId)throws EMSException;
	Employee getEmployeeById(int empId)throws EMSException;
	
	List<Employee> getAllEmployees()throws EMSException;
}
