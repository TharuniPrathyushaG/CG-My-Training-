create table emp810 (
	empId number(4) primary key,
	name varchar2(50) not null,
	basic number(12,2) not null,
	Gender varchar2(10) not null,
	doj date not null

);

create sequence emp_code_seq
start with 101
increment by 1;