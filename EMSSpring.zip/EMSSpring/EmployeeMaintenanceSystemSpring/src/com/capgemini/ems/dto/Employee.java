package com.capgemini.ems.dto;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.NotEmpty;
import org.hibernate.validator.constraints.Range;
import org.springframework.format.annotation.DateTimeFormat;

import com.sun.istack.internal.NotNull;

@Entity
@Table(name = "ems")
public class Employee {

	@Id
	@NotEmpty(message = "Please enter Id.")
	@Pattern(regexp = "[1][0-9]{5}", message = "Id must be 6 digits beginning with 1")
	private String empId;

	@NotEmpty(message = "Please enter first Name")
	@Size(min = 4, max = 40, message = "Name should be of 4 to 40 characters in length")
	@Pattern(regexp = "[A-Z]{1}[A-Za-z]{3,39}", message = "Name should contain only alphabets, starting with capital letter")
	private String empFirstName;

	@NotEmpty(message = "Please enter last Name")
	@Size(min = 4, max = 40, message = "Name should be of 4 to 40 characters in length")
	@Pattern(regexp = "[A-Z]{1}[A-Za-z]{3,39}", message = "Name should contain only alphabets, starting with capital letter")
	private String empLastName;

	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate empDateOfBirth;

	@NotNull
	@DateTimeFormat(pattern = "yyyy-MM-dd")
	private LocalDate empDateOfJoining;

	@NotEmpty(message = "Please select department")
	private String deptId;

	@NotEmpty(message = "Please select grade")
	private String grade;

	@NotNull
	@Range(min = 25000, max = 100000, message = "Salary should range between 25000 and 100000")
	private int empBasic;

	@NotEmpty(message = "Please select gender")
	private String gender;

	@NotEmpty(message = "Please select marital status")
	private String empMaritalStatus;

	@NotEmpty(message = "Please select designation")
	private String designation;

	@NotEmpty(message = "Please enter address")
	@Size(min = 5, max = 100, message = "Address should be in the range of 5-100 characters")
	private String empHomeAddress;

	@NotEmpty
	@Pattern(regexp = "[1-9][0-9]{9}", message = "Please enter 10 digit mobile number")
	private String contactNumber;

	public Employee() {
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getEmpFirstName() {
		return empFirstName;
	}

	public void setEmpFirstName(String empFirstName) {
		this.empFirstName = empFirstName;
	}

	public String getEmpLastName() {
		return empLastName;
	}

	public void setEmpLastName(String empLastName) {
		this.empLastName = empLastName;
	}

	public LocalDate getEmpDateOfBirth() {
		return empDateOfBirth;
	}

	public void setEmpDateOfBirth(LocalDate empDateOfBirth) {
		this.empDateOfBirth = empDateOfBirth;
	}

	public LocalDate getEmpDateOfJoining() {
		return empDateOfJoining;
	}

	public void setEmpDateOfJoining(LocalDate empDateOfJoining) {
		this.empDateOfJoining = empDateOfJoining;
	}

	public String getDeptId() {
		return deptId;
	}

	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public int getEmpBasic() {
		return empBasic;
	}

	public void setEmpBasic(int empBasic) {
		this.empBasic = empBasic;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmpMaritalStatus() {
		return empMaritalStatus;
	}

	public void setEmpMaritalStatus(String empMaritalStatus) {
		this.empMaritalStatus = empMaritalStatus;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public String getEmpHomeAddress() {
		return empHomeAddress;
	}

	public void setEmpHomeAddress(String empHomeAddress) {
		this.empHomeAddress = empHomeAddress;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

}
