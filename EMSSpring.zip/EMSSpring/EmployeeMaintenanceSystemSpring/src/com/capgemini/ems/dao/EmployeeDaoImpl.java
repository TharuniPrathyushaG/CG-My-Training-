package com.capgemini.ems.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.dto.UserMasterBean;
import com.capgemini.ems.exception.EMSException;

@Repository
@Transactional
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	private EntityManager entityManager;
	
	
	/***********************************
	 * Method Name      : loginAuthentication
	 * Input Parameters : userName,password
	 * Return Type		: List
	 * Class Name       : EmloyeeDaoImpl
	 * Package Name     : com.capgemini.ems.dao
	 * Author		    : D.Monica,T.Swetha
	 * Date             : 30/01/2017
	 * Description      : Returns userList for authentication
	 ***********************************/
	
	@Override
	public List<UserMasterBean> loginAuthenticate(String userName,
			String password) throws EMSException {

		Query queryOne = entityManager
				.createQuery("FROM UserMasterBean WHERE userName=:userName AND userPassword=:password");
		queryOne.setParameter("userName", userName);
		queryOne.setParameter("password", password);
		List<UserMasterBean> userList = queryOne.getResultList();
		return userList;
	}
	
	/***********************************
	 * Method Name   	: addEmployee
	 * Input Parameters : employeeBean
	 * Return Type		: EmployeeBean
	 * Class Name    	: EmployeeDaoImpl
	 * Package Name  	: com.capgemini.ems.dao
	 * Date          	: 30/01/2017
	 * Author   		: D.Monica,T.Swetha
	 * Description   	: Adding details of an employee
	 ***********************************/
	
	@Override
	public Employee addEmployee(Employee employeeBean) throws EMSException {
		entityManager.persist(employeeBean);
		entityManager.flush();
		return employeeBean;
	}

}
