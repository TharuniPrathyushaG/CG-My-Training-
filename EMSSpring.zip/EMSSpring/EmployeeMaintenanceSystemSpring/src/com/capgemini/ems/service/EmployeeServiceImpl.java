
package com.capgemini.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.ems.dao.IEmployeeDao;
import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.dto.UserMasterBean;
import com.capgemini.ems.exception.EMSException;

@Service
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDao employeeDao;
	
	public IEmployeeDao getEmployeeDao() {
		return employeeDao;
	}

	public void setEmployeeDao(IEmployeeDao employeeDao) {
		this.employeeDao = employeeDao;
	}

	
	/***********************************
	 * Method Name      : loginAuthentication
	 * Input Parameters : userName,password
	 * Return Type		: List
	 * Class Name       : EmloyeeServiceImpl
	 * Package Name     : com.capgemini.ems.service
	 * Date             : 30/01/2017
	 * Author			: D.Monica,T.Swetha
	 * Description      : Returns userList for authentication
	 ***********************************/
	
	@Override
	public List<UserMasterBean> loginAuthenticate(String userName,
			String password) throws EMSException {
		return employeeDao.loginAuthenticate(userName,password);	
		
	}

	
	/***********************************
	 * Method Name      : addEmployee
	 * Input Parameters : employeeBean
	 * Return Type		: EmployeeBean
	 * Class Name       : EmloyeeServiceImpl
	 * Package Name     : com.capgemini.ems.service
	 * Date             : 30/01/2017
	 * Author			: D.Monica,T.Swetha
	 * Description      : Adding details of an employee
	 ***********************************/
	
	@Override
	public Employee addEmployee(Employee employeeBean) throws EMSException {
		return employeeDao.addEmployee(employeeBean);
		
	}
	
}
