package com.capgemini.ems.service;

import java.util.List;

import com.capgemini.ems.dto.Employee;
import com.capgemini.ems.dto.UserMasterBean;
import com.capgemini.ems.exception.EMSException;

public interface IEmployeeService {

	public List<UserMasterBean> loginAuthenticate(String userName,String password) throws EMSException;
	public Employee addEmployee(Employee employeeBean)throws EMSException;
}
