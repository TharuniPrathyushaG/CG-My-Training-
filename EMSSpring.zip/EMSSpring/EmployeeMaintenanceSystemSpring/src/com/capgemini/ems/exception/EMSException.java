package com.capgemini.ems.exception;

public class EMSException extends Exception {
	
	
	/***********************************
	 * Constructor Name : EMSException(message)
	 * Class Name       : EMSException
	 * Package Name     : com.capgemini.ems.exception
	 * Date             : 30/01/2017
	 * Description      : Returns userDefined exception
	 ***********************************/
	
	public EMSException(String message) {
		
		super(message);
	}

}
