package com.capgemini.ems.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.ems.dto.Employee;
/*import com.capgemini.ems.dto.EmployeeBean;
 */
import com.capgemini.ems.dto.UserMasterBean;
import com.capgemini.ems.exception.EMSException;
import com.capgemini.ems.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService service;

	HttpSession sess;

	public IEmployeeService getService() {
		return service;
	}

	public void setService(IEmployeeService service) {
		this.service = service;
	}

	@RequestMapping("/index.obj")
	public String showHomePage() {
		return "pages/index";
	}

	@RequestMapping("/loginPage.obj")
	public String showLoginPage() {
		return "pages/loginPage";
	}

	@RequestMapping(value = "/confirmLogin", method = RequestMethod.POST)
	public ModelAndView confirmLogin(
			@ModelAttribute("user") UserMasterBean user,
			@RequestParam("userName") String userName,
			@RequestParam("password") String password) throws EMSException {

		if (userName != null && password != null) {
			try {
				List<UserMasterBean> users = service.loginAuthenticate(
						userName, password);
				if (users.isEmpty()) {
					String message = "Invalid Username and Password! Please try Again!";
					return new ModelAndView("pages/loginPage", "error", message);

				} else {
					return new ModelAndView("pages/AdminMainOptionScreen");
				}
			} catch (EMSException e) {
				throw new EMSException("Invalid Username and Password! Please try Again!");

			}

		}
		return new ModelAndView("pages/AdminMainOptionScreen");

	}

	@RequestMapping(value = "/addEmployee", method = RequestMethod.POST)
	public ModelAndView showNewEmployee(@RequestParam("add") String add)
			throws EMSException {

		ModelAndView mv = null;
		Employee employee = new Employee();
		mv = new ModelAndView("pages/AddEmployee", "employee", employee);
		return mv;
	}

	@RequestMapping(value = "/addSuccess", method = RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute @Valid Employee employee,
			BindingResult result) throws EMSException {
		ModelAndView mv = null;
		if (!result.hasErrors()) {
			service.addEmployee(employee);
			mv = new ModelAndView("pages/addSuccess", "employee", employee);
		} else {
			mv = new ModelAndView("pages/AddEmployee", "employee", employee);
		}
		return mv;

	}
}
